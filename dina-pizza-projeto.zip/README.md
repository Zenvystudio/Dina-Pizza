# 🍕 Dina Pizza - Landing Page & Cardápio Digital

Website de alta conversão e direção de arte premium para a **Dina Pizza**.

## 🚀 Como hospedar na Netlify (Opção mais rápida - 1 minuto)

### Método 1: Netlify Drop (Sem Git, apenas arrastar a pasta `dist`)
1. Acesse: [app.netlify.com/drop](https://app.netlify.com/drop)
2. Descompacte o arquivo `dina-pizza-dist-netlify.zip` (ou use a pasta `dist` após rodar `npm run build`).
3. Arraste a pasta `dist` diretamente para a área indicada na Netlify.
4. Seu site estará online com HTTPS gratuito imediatamente!

### Método 2: Conectar ao GitHub / Netlify Git
- **Build command**: `npm run build`
- **Publish directory**: `dist`

---

## 💜 Como usar no Lovable
1. No [Lovable.dev](https://lovable.dev), crie um novo projeto ou conecte ao repositório GitHub.
2. Extraia o conteúdo deste arquivo `.zip` e faça o upload ou commit no repositório.
3. As dependências já estão configuradas em `package.json` (React 19, Tailwind CSS v4, Lucide React, Motion).

---

## 💻 Como rodar localmente na sua máquina
1. Extraia o arquivo `.zip`.
2. Abra a pasta no terminal ou VS Code.
3. Instale as dependências:
   ```bash
   npm install
   ```
4. Inicie o servidor local:
   ```bash
   npm run dev
   ```
5. Para gerar a versão de produção:
   ```bash
   npm run build
   ```
