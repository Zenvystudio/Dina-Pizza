export interface PizzaItem {
  id: string;
  name: string;
  category: 'classicas' | 'especiais';
  price: number;
  description: string;
  highlight: string;
  image: string;
}

export const RESTAURANT_INFO = {
  name: 'Dina Pizza',
  headline: 'Fogo a lenha, alma italiana.',
  subheadline: 'Massa de fermentação lenta por 48 horas e ingredientes nobres assados a 450°C.',
  address: 'Av. Rui Barbosa, 4652 - Parque da Fonte, São José dos Pinhais - PR, 83050-380',
  shortAddress: 'São José dos Pinhais, PR',
  phoneDisplay: '(41) 93385-0874',
  phoneSanitized: '5541933850874',
  googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=Av.+Rui+Barbosa,+4652+-+Parque+da+Fonte,+São+José+dos+Pinhais+-+PR,+83050-380',
};

export const MENU_ITEMS: PizzaItem[] = [
  {
    id: 'margherita',
    name: 'Margherita Speciale',
    category: 'classicas',
    price: 68,
    description: 'Molho San Marzano D.O.P., mozzarella de búfala fresca, folhas de manjericão e fio de azeite extravirgem.',
    highlight: 'Molho artesanal San Marzano',
    image: '/src/assets/images/pizza_margherita_1792118357674.jpg',
  },
  {
    id: 'pepperoni',
    name: 'Pepperoni Artesanal',
    category: 'especiais',
    price: 74,
    description: 'Fatias crocantes de pepperoni especial, mozzarella derretida na brasa, orégano fresco e toque sutil de mel picante.',
    highlight: 'Receita autoral Dina',
    image: '/src/assets/images/pizza_pepperoni_1792118358640.jpg',
  },
  {
    id: 'quatro-queijos',
    name: 'Quatro Queijos Nobres',
    category: 'especiais',
    price: 76,
    description: 'Harmonização de fior di latte, gorgonzola doce, lascas de parmesão maturado e requeijão artesanal.',
    highlight: 'Queijos de cura selecionada',
    image: '/src/assets/images/pizza_quatro_queijos_1792118358425.jpg',
  },
  {
    id: 'calabresa',
    name: 'Calabresa na Brasa',
    category: 'classicas',
    price: 64,
    description: 'Linguiça calabresa artesanal levemente defumada, cebolas caramelizadas no forno, azeitonas pretas e orégano.',
    highlight: 'Defumação em lenha nobre',
    image: '/src/assets/images/pizza_calabresa_1792118419346.jpg',
  },
];

export const STATS = [
  { value: '12', label: 'Anos de história no fogo a lenha' },
  { value: '48h', label: 'Fermentação natural lenta da massa' },
  { value: '3.200', label: 'Pizzas artesanais assadas por mês' },
  { value: '4.9★', label: 'Média de satisfação dos clientes' },
];

export function buildWhatsAppLink(message: string): string {
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${RESTAURANT_INFO.phoneSanitized}?text=${encoded}`;
}
