import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { CartDrawer, CartItem } from './components/CartDrawer';
import { PizzaItem, RESTAURANT_INFO, buildWhatsAppLink } from './data/menu';
import { MessageCircle } from 'lucide-react';

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const handleAddToCart = (item: PizzaItem) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.item.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.item.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { item, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((i) => {
          if (i.item.id === id) {
            const nextQty = i.quantity + delta;
            return nextQty > 0 ? { ...i, quantity: nextQty } : null;
          }
          return i;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemove = (id: string) => {
    setCart((prev) => prev.filter((i) => i.item.id !== id));
  };

  const handleClear = () => {
    setCart([]);
  };

  const totalCartCount = cart.reduce((acc, curr) => acc + curr.quantity, 0);

  return (
    <div className="min-h-screen bg-canvas text-main selection:bg-primary-pepperoni selection:text-white flex flex-col">
      {/* Top Navigation */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Main Sections */}
      <main className="flex-1">
        <Hero />
        <MenuSection
          onAddToCart={handleAddToCart}
          cartItemIds={cart.map((c) => c.item.id)}
        />
        <AboutSection />
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Interactive Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemove={handleRemove}
        onClear={handleClear}
      />

      {/* Persistent Floating Quick WhatsApp button on bottom-right */}
      <aside aria-label="Atendimento rápido via WhatsApp" className="fixed bottom-6 right-6 z-40">
        <a
          href={buildWhatsAppLink('Olá! Gostaria de fazer um pedido na Dina Pizza.')}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Pedir pelo WhatsApp"
          className="flex items-center justify-center w-14 h-14 rounded-full bg-primary-pepperoni hover:bg-primary-hover text-white shadow-2xl shadow-[#E31837]/40 transition-all duration-300 hover:scale-110 active:scale-95 border border-white/20"
        >
          <MessageCircle className="w-6 h-6" />
        </a>
      </aside>
    </div>
  );
}
