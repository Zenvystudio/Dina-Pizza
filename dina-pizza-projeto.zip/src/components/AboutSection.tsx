import React from 'react';
import { motion } from 'motion/react';
import { STATS } from '../data/menu';

export const AboutSection: React.FC = () => {
  return (
    <section id="tradicao" className="py-24 sm:py-36 relative overflow-hidden">
      {/* Subtle background ambient line */}
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-center">
          
          {/* Left Column: Asymmetric Editorial Narrative */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <div className="inline-flex items-center gap-2 mb-4 text-xs uppercase tracking-[0.25em] text-secondary-gold font-medium">
              <span className="w-6 h-[1px] bg-secondary-gold/50" />
              <span>Nossa Tradição</span>
            </div>

            <h2 className="section-title font-display font-bold text-main mb-6 [text-wrap:balance]">
              Tempo, fogo e paciência.
            </h2>

            <p className="text-base sm:text-lg text-muted font-light leading-relaxed mb-6">
              Na Dina Pizza, não acreditamos em atalhos. Cada massa descansa por 48 horas em maturação lenta para criar uma crosta aerada, leve e de fácil digestão.
            </p>

            <p className="text-base sm:text-lg text-muted font-light leading-relaxed">
              O forno a lenha trabalha a 450°C, caramelizando os molhos italianos e defumando sutilmente cada fatia em noventa segundos inesquecíveis.
            </p>
          </motion.div>

          {/* Right Column: Quantitative Proof Grid with Tabular Figures */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <div className="grid grid-cols-2 gap-6 sm:gap-8">
              {STATS.map((stat, idx) => (
                <div
                  key={stat.label}
                  className={`p-6 sm:p-8 rounded-xl bg-surface border border-subtle transition-all duration-300 hover:border-gold/40 flex flex-col justify-between ${
                    idx === 0 ? 'bg-gradient-to-br from-[#1E1410] to-surface' : ''
                  }`}
                >
                  <div className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-secondary-gold tabular-nums tracking-tight mb-2">
                    {stat.value}
                  </div>
                  <div className="text-xs sm:text-sm text-muted font-light leading-snug">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
