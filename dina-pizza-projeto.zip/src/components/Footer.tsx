import React from 'react';
import { ArrowUp } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/menu';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="py-16 sm:py-20 border-t border-subtle bg-[#080605] text-muted text-xs">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 flex flex-col md:flex-row items-center justify-between gap-8">
        
        {/* Brand & Address */}
        <div className="flex flex-col items-center md:items-start gap-2 text-center md:text-left">
          <div className="font-display text-xl font-bold text-main tracking-tight">
            <span className="text-secondary-gold">Dina</span> Pizza
          </div>
          <p className="font-light text-muted/80 max-w-sm">
            {RESTAURANT_INFO.address}
          </p>
        </div>

        {/* Center Nav Links */}
        <div className="flex items-center gap-6 text-xs uppercase tracking-wider font-medium">
          <a href="#inicio" className="hover:text-main transition-colors">
            Início
          </a>
          <a href="#cardapio" className="hover:text-main transition-colors">
            Cardápio
          </a>
          <a href="#tradicao" className="hover:text-main transition-colors">
            Tradição
          </a>
          <a href="#contato" className="hover:text-main transition-colors">
            Contato
          </a>
        </div>

        {/* Right: Copyright & Back to Top */}
        <div className="flex items-center gap-6">
          <span className="text-muted/60">
            © {new Date().getFullYear()} Dina Pizza. Todos os direitos reservados.
          </span>
          <button
            type="button"
            onClick={scrollToTop}
            aria-label="Voltar ao início"
            className="p-2.5 rounded-lg border border-subtle hover:border-gold/40 text-muted hover:text-white transition-all bg-surface"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Direct ZIP Export Bar for User Hosting (Lovable / Netlify) */}
      <div className="max-w-7xl mx-auto px-6 sm:px-8 mt-12 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-2 text-muted/70">
          <span className="font-medium text-main">Download dos Arquivos para Hospedagem:</span>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <a
            href="/dina-pizza-projeto.zip"
            download="dina-pizza-projeto.zip"
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-md bg-surface border border-gold/30 hover:border-gold text-secondary-light hover:text-white transition-all"
          >
            <span>📦 Baixar Código Completo (Lovable / GitHub)</span>
          </a>
          <a
            href="/dina-pizza-dist-netlify.zip"
            download="dina-pizza-dist-netlify.zip"
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-md bg-surface border border-subtle hover:border-gold/30 text-muted hover:text-white transition-all"
          >
            <span>🚀 Baixar Build Pronto (Netlify Drop)</span>
          </a>
        </div>
      </div>
    </footer>
  );
};
