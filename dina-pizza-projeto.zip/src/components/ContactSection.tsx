import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Phone, MessageCircle, Send, Navigation } from 'lucide-react';
import { RESTAURANT_INFO, MENU_ITEMS } from '../data/menu';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    nome: '',
    telefone: '',
    tipo: 'entrega' as 'entrega' | 'retirada' | 'reserva',
    pizzaId: 'margherita',
    observacao: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.nome.trim()) {
      newErrors.nome = 'Por favor, informe seu nome.';
    }
    if (!formData.telefone.trim() || formData.telefone.length < 8) {
      newErrors.telefone = 'Informe um telefone válido.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const selectedPizza = MENU_ITEMS.find((p) => p.id === formData.pizzaId);
    const tipoLabel =
      formData.tipo === 'entrega'
        ? 'Entrega em domicílio'
        : formData.tipo === 'retirada'
        ? 'Retirada no balcão'
        : 'Reserva de mesa';

    let msg = `Olá, Dina Pizza! Me chamo *${formData.nome.trim()}*.\n`;
    msg += `• Tipo: ${tipoLabel}\n`;
    if (selectedPizza) {
      msg += `• Pizza de interesse: *${selectedPizza.name}* (R$ ${selectedPizza.price})\n`;
    }
    if (formData.observacao.trim()) {
      msg += `• Detalhes/Endereço: ${formData.observacao.trim()}\n`;
    }
    msg += `• Meu contato: ${formData.telefone.trim()}`;

    const url = `https://wa.me/${RESTAURANT_INFO.phoneSanitized}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-24 sm:py-36 relative bg-surface/40 border-t border-subtle">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Heading */}
        <div className="mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 mb-4 text-xs uppercase tracking-[0.25em] text-secondary-gold font-medium">
            <span className="w-6 h-[1px] bg-secondary-gold/50" />
            <span>Localização & Contato</span>
          </div>
          <h2 className="section-title font-display font-bold text-main [text-wrap:balance]">
            Sua mesa ou na sua casa.
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Direct Coordinates & Quick Call */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex flex-col gap-8"
          >
            {/* Address Block */}
            <div className="p-8 rounded-xl bg-surface border border-subtle">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-[#1F1713] text-secondary-gold border border-gold/20 shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-secondary-gold mb-2">
                    Endereço
                  </h3>
                  <p className="text-base text-main font-light leading-relaxed mb-4">
                    {RESTAURANT_INFO.address}
                  </p>
                  <a
                    href={RESTAURANT_INFO.googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-secondary-light hover:text-white transition-colors"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Ver rota no Google Maps</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Direct Phone & WhatsApp Block */}
            <div className="p-8 rounded-xl bg-surface border border-subtle">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-[#241315] text-primary-pepperoni border border-pepperoni shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-primary-pepperoni mb-2">
                    Telefone & WhatsApp
                  </h3>
                  <a
                    href={`tel:+${RESTAURANT_INFO.phoneSanitized}`}
                    className="font-display text-2xl font-bold text-main hover:text-secondary-gold transition-colors block mb-4"
                  >
                    {RESTAURANT_INFO.phoneDisplay}
                  </a>

                  <a
                    href={`https://wa.me/${RESTAURANT_INFO.phoneSanitized}?text=Olá!%20Gostaria%20de%20fazer%20um%20pedido%20na%20Dina%20Pizza.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 text-xs font-semibold tracking-wider uppercase text-white bg-primary-pepperoni rounded-lg hover:bg-primary-hover transition-all duration-300 shadow-md shadow-[#E31837]/20"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Abrir conversa no WhatsApp</span>
                  </a>
                </div>
              </div>
            </div>

            <div className="text-xs text-muted/70 leading-relaxed px-2">
              Atendimento exclusivo para pedidos para viagem, entrega expressa e reservas de salão em São José dos Pinhais.
            </div>
          </motion.div>

          {/* Right Column: Clean validated WhatsApp Order Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 bg-surface border border-subtle rounded-xl p-8 sm:p-10"
          >
            <div className="mb-8">
              <h3 className="font-display text-2xl font-bold text-main mb-2">
                Envie seu pedido ou reserva
              </h3>
              <p className="text-sm text-muted font-light">
                Preencha os detalhes e enviaremos seu pedido formatado instantaneamente ao nosso WhatsApp.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="flex flex-col gap-6" noValidate>
              {/* Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="nome" className="block text-xs uppercase tracking-wider font-semibold text-muted mb-2">
                    Seu Nome *
                  </label>
                  <input
                    id="nome"
                    type="text"
                    required
                    value={formData.nome}
                    onChange={(e) => {
                      setFormData({ ...formData, nome: e.target.value });
                      if (errors.nome) setErrors({ ...errors, nome: '' });
                    }}
                    placeholder="Ex: Carlos Silva"
                    className={`w-full px-4 py-3 bg-[#0B0908] border rounded-lg text-sm text-main placeholder-muted/40 focus:outline-none focus:ring-1 transition-all ${
                      errors.nome
                        ? 'border-primary-pepperoni focus:ring-primary-pepperoni'
                        : 'border-subtle focus:border-gold focus:ring-secondary-gold'
                    }`}
                  />
                  {errors.nome && <p className="mt-1.5 text-xs text-primary-pepperoni">{errors.nome}</p>}
                </div>

                <div>
                  <label htmlFor="telefone" className="block text-xs uppercase tracking-wider font-semibold text-muted mb-2">
                    WhatsApp ou Telefone *
                  </label>
                  <input
                    id="telefone"
                    type="tel"
                    required
                    value={formData.telefone}
                    onChange={(e) => {
                      setFormData({ ...formData, telefone: e.target.value });
                      if (errors.telefone) setErrors({ ...errors, telefone: '' });
                    }}
                    placeholder="(41) 99999-9999"
                    className={`w-full px-4 py-3 bg-[#0B0908] border rounded-lg text-sm text-main placeholder-muted/40 focus:outline-none focus:ring-1 transition-all ${
                      errors.telefone
                        ? 'border-primary-pepperoni focus:ring-primary-pepperoni'
                        : 'border-subtle focus:border-gold focus:ring-secondary-gold'
                    }`}
                  />
                  {errors.telefone && <p className="mt-1.5 text-xs text-primary-pepperoni">{errors.telefone}</p>}
                </div>
              </div>

              {/* Order Mode & Pizza selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="tipo" className="block text-xs uppercase tracking-wider font-semibold text-muted mb-2">
                    Tipo de Atendimento
                  </label>
                  <select
                    id="tipo"
                    value={formData.tipo}
                    onChange={(e) => setFormData({ ...formData, tipo: e.target.value as any })}
                    className="w-full px-4 py-3 bg-[#0B0908] border border-subtle rounded-lg text-sm text-main focus:outline-none focus:border-gold focus:ring-1 focus:ring-secondary-gold"
                  >
                    <option value="entrega">Entrega em Domicílio</option>
                    <option value="retirada">Retirada no Balcão</option>
                    <option value="reserva">Reserva de Mesa</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="pizza" className="block text-xs uppercase tracking-wider font-semibold text-muted mb-2">
                    Pizza Preferida
                  </label>
                  <select
                    id="pizza"
                    value={formData.pizzaId}
                    onChange={(e) => setFormData({ ...formData, pizzaId: e.target.value })}
                    className="w-full px-4 py-3 bg-[#0B0908] border border-subtle rounded-lg text-sm text-main focus:outline-none focus:border-gold focus:ring-1 focus:ring-secondary-gold"
                  >
                    {MENU_ITEMS.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.name} — R$ {item.price}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Message / Address details */}
              <div>
                <label htmlFor="observacao" className="block text-xs uppercase tracking-wider font-semibold text-muted mb-2">
                  Endereço de Entrega ou Observação
                </label>
                <textarea
                  id="observacao"
                  rows={3}
                  value={formData.observacao}
                  onChange={(e) => setFormData({ ...formData, observacao: e.target.value })}
                  placeholder="Ex: Rua, número, complemento e ponto de referência ou horário pretendido..."
                  className="w-full px-4 py-3 bg-[#0B0908] border border-subtle rounded-lg text-sm text-main placeholder-muted/40 focus:outline-none focus:border-gold focus:ring-1 focus:ring-secondary-gold resize-none"
                />
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-3 w-full py-4 text-xs font-semibold uppercase tracking-wider text-white bg-primary-pepperoni rounded-lg hover:bg-primary-hover transition-all duration-300 shadow-xl shadow-[#E31837]/25 hover:shadow-[#E31837]/40 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Enviar pedido direto para o WhatsApp</span>
              </button>
            </form>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
