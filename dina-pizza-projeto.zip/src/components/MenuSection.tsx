import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Plus, Check, MessageCircle } from 'lucide-react';
import { MENU_ITEMS, PizzaItem, buildWhatsAppLink } from '../data/menu';

interface MenuSectionProps {
  onAddToCart: (item: PizzaItem) => void;
  cartItemIds: string[];
}

export const MenuSection: React.FC<MenuSectionProps> = ({ onAddToCart, cartItemIds }) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'classicas' | 'especiais'>('all');

  const filteredItems = MENU_ITEMS.filter((item) =>
    activeCategory === 'all' ? true : item.category === activeCategory
  );

  return (
    <section id="cardapio" className="py-24 sm:py-32 relative bg-surface/30">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header: Minimal, bold, generous breathing room */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 sm:mb-20 gap-8">
          <div>
            <div className="inline-flex items-center gap-2 mb-4 text-xs uppercase tracking-[0.25em] text-secondary-gold font-medium">
              <span className="w-6 h-[1px] bg-secondary-gold/50" />
              <span>Cardápio Digital</span>
            </div>
            <h2 className="section-title font-display font-bold text-main [text-wrap:balance]">
              Receitas feitas à mão.
            </h2>
          </div>

          {/* Functional Category Filter Segmented Control (zero pill candy, clean interactive tabs) */}
          <div className="flex items-center p-1 bg-surface border border-subtle rounded-lg self-start md:self-auto">
            <button
              type="button"
              onClick={() => setActiveCategory('all')}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-md transition-all duration-200 ${
                activeCategory === 'all'
                  ? 'bg-primary-pepperoni text-white shadow-md'
                  : 'text-muted hover:text-main'
              }`}
            >
              Todas
            </button>
            <button
              type="button"
              onClick={() => setActiveCategory('classicas')}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-md transition-all duration-200 ${
                activeCategory === 'classicas'
                  ? 'bg-primary-pepperoni text-white shadow-md'
                  : 'text-muted hover:text-main'
              }`}
            >
              Clássicas
            </button>
            <button
              type="button"
              onClick={() => setActiveCategory('especiais')}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-md transition-all duration-200 ${
                activeCategory === 'especiais'
                  ? 'bg-primary-pepperoni text-white shadow-md'
                  : 'text-muted hover:text-main'
              }`}
            >
              Especiais
            </button>
          </div>
        </div>

        {/* Dynamic Editorial Grid: 2 columns with generous padding and alternating image rhythm */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 sm:gap-14">
          {filteredItems.map((item, index) => {
            const isAdded = cartItemIds.includes(item.id);
            const directWhatsAppUrl = buildWhatsAppLink(
              `Olá! Gostaria de pedir uma pizza *${item.name}* (R$ ${item.price}) na Dina Pizza.`
            );

            return (
              <motion.article
                key={item.id}
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.6, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] }}
                className="group flex flex-col bg-surface border border-subtle hover:border-gold/40 rounded-xl overflow-hidden transition-all duration-500 hover:shadow-2xl hover:shadow-black/50"
              >
                {/* Image frame with zoom and ratio */}
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#161210]">
                  <img
                    src={item.image}
                    alt={item.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#14100E] via-transparent to-transparent opacity-80 pointer-events-none" />

                  {/* Clean unboxed category badge */}
                  <div className="absolute top-4 left-4 text-xs font-medium uppercase tracking-widest text-secondary-light/90 drop-shadow">
                    {item.highlight}
                  </div>

                  {/* Price display with Playfair serif tabular elegance */}
                  <div className="absolute bottom-4 right-4 bg-[#0B0908]/85 backdrop-blur-md px-3.5 py-1.5 rounded-md border border-gold/30">
                    <span className="text-xs text-secondary-light font-light mr-1">R$</span>
                    <span className="font-display font-bold text-lg sm:text-xl text-secondary-gold tabular-nums">
                      {item.price}
                    </span>
                  </div>
                </div>

                {/* Content block: clean typography and generous spacing */}
                <div className="p-6 sm:p-8 flex flex-col justify-between flex-1">
                  <div>
                    <h3 className="font-display text-xl sm:text-2xl font-bold text-main mb-3 group-hover:text-secondary-gold transition-colors duration-300">
                      {item.name}
                    </h3>
                    <p className="text-muted text-sm sm:text-base leading-relaxed font-light mb-6">
                      {item.description}
                    </p>
                  </div>

                  {/* Action row: WhatsApp direct order + Add to selection */}
                  <div className="pt-4 border-t border-white/5 flex items-center justify-between gap-4">
                    <a
                      href={directWhatsAppUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-white hover:text-secondary-gold transition-colors"
                    >
                      <MessageCircle className="w-4 h-4 text-primary-pepperoni" />
                      <span>Pedir no WhatsApp</span>
                    </a>

                    <button
                      type="button"
                      onClick={() => onAddToCart(item)}
                      className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-lg transition-all duration-300 ${
                        isAdded
                          ? 'bg-secondary-gold text-[#0B0908]'
                          : 'bg-white/5 hover:bg-primary-pepperoni text-main hover:text-white border border-white/10'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Adicionado</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" />
                          <span>Selecionar</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
};
