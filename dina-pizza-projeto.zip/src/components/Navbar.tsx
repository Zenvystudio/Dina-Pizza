import React, { useState, useEffect } from 'react';
import { ShoppingBag, Menu, X, ArrowUpRight } from 'lucide-react';
import { RESTAURANT_INFO, buildWhatsAppLink } from '../data/menu';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ cartCount, onOpenCart }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Cardápio', href: '#cardapio' },
    { label: 'Tradição', href: '#tradicao' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#0B0908]/90 backdrop-blur-md border-b border-subtle py-4 shadow-2xl'
          : 'bg-transparent py-6 border-b border-white/5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#inicio"
          className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-main whitespace-nowrap shrink-0 group flex items-center gap-2"
        >
          <span className="text-secondary-gold transition-colors duration-300 group-hover:text-primary-pepperoni">
            Dina
          </span>
          <span>Pizza</span>
        </a>

        {/* Zone 2: 4 nav links, single-line text */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-muted">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="whitespace-nowrap shrink-0 transition-colors duration-200 hover:text-main relative py-1 after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-secondary-gold hover:after:w-full after:transition-all after:duration-300"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href="/dina-pizza-projeto.zip"
            download="dina-pizza-projeto.zip"
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold uppercase tracking-wider text-secondary-gold border border-gold/40 hover:border-gold hover:bg-secondary-gold/10 rounded-lg transition-all"
            title="Baixar projeto completo (.zip)"
          >
            <span>📥 Baixar ZIP</span>
          </a>

          {cartCount > 0 && (
            <button
              onClick={onOpenCart}
              type="button"
              aria-label="Abrir pedido"
              className="relative p-2.5 rounded-full border border-gold bg-surface text-secondary-gold hover:text-white transition-colors duration-200"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-primary-pepperoni text-white text-[11px] font-bold flex items-center justify-center tabular-nums">
                {cartCount}
              </span>
            </button>
          )}

          <a
            href={buildWhatsAppLink('Olá! Gostaria de fazer um pedido na Dina Pizza.')}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold tracking-wider uppercase text-white bg-primary-pepperoni rounded-lg hover:bg-primary-hover transition-all duration-300 shadow-lg shadow-[#E31837]/20 whitespace-nowrap shrink-0 hover:scale-[1.02] active:scale-[0.98]"
          >
            <span>Entrar em contato</span>
            <ArrowUpRight className="w-3.5 h-3.5 opacity-80" />
          </a>

          {/* Mobile hamburger toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            type="button"
            aria-label="Menu de navegação"
            className="md:hidden p-2 text-muted hover:text-main transition-colors"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-b border-subtle bg-[#0B0908]/98 backdrop-blur-xl px-6 py-6 transition-all">
          <nav className="flex flex-col gap-4 text-base font-medium">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-2 text-muted hover:text-secondary-gold transition-colors border-b border-white/5"
              >
                {link.label}
              </a>
            ))}
            <a
              href="/dina-pizza-projeto.zip"
              download="dina-pizza-projeto.zip"
              onClick={() => setIsMobileMenuOpen(false)}
              className="py-2 text-secondary-gold hover:text-white transition-colors border-b border-white/5 flex items-center justify-between"
            >
              <span>📥 Baixar Projeto ZIP (Lovable/Netlify)</span>
            </a>
            <a
              href={buildWhatsAppLink('Olá! Gostaria de fazer um pedido na Dina Pizza.')}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setIsMobileMenuOpen(false)}
              className="mt-2 inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold tracking-wider uppercase text-white bg-primary-pepperoni rounded-lg hover:bg-primary-hover transition-colors text-center"
            >
              <span>Entrar em contato</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};
