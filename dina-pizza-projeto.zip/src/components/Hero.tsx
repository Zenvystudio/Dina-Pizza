import React from 'react';
import { motion } from 'motion/react';
import { ArrowDown, MessageCircle, UtensilsCrossed } from 'lucide-react';
import { RESTAURANT_INFO, buildWhatsAppLink } from '../data/menu';

export const Hero: React.FC = () => {
  return (
    <section
      id="inicio"
      className="relative min-h-[92vh] pt-32 pb-16 flex flex-col justify-between overflow-hidden"
    >
      {/* Background glow ambiance */}
      <div
        className="pointer-events-none absolute top-10 left-1/2 -translate-x-1/2 w-[700px] h-[500px] rounded-full blur-[140px] opacity-20 bg-[#E31837]"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -bottom-20 right-0 w-[450px] h-[450px] rounded-full blur-[160px] opacity-15 bg-[#D4AF37]"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 w-full flex-1 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Bold Minimalist Editorial Statement */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col items-start z-10"
          >
            {/* Subtle editorial kicker */}
            <div className="inline-flex items-center gap-2 mb-6 text-xs uppercase tracking-[0.25em] text-secondary-gold font-medium">
              <span className="w-6 h-[1px] bg-secondary-gold/50" />
              <span>Pizzaria Artesanal Dina</span>
            </div>

            {/* Giant Title: Max 8 words, tight line height */}
            <h1 className="hero-title font-display font-bold text-main mb-6 [text-wrap:balance]">
              Fogo a lenha, <br />
              <span className="text-secondary-gold italic font-normal">alma</span> italiana.
            </h1>

            {/* Single concise supporting sentence */}
            <p className="text-base sm:text-lg text-muted max-w-lg mb-8 leading-relaxed font-light">
              Massa de fermentação lenta por 48 horas e ingredientes nobres assados a 450°C.
            </p>

            {/* Primary CTA + Secondary direct WhatsApp link */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
              <a
                href={buildWhatsAppLink('Olá! Gostaria de fazer um pedido na Dina Pizza.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 px-8 py-4 text-sm font-semibold tracking-wider uppercase text-white bg-primary-pepperoni rounded-lg hover:bg-primary-hover transition-all duration-300 shadow-xl shadow-[#E31837]/25 hover:shadow-[#E31837]/40 hover:-translate-y-0.5 active:translate-y-0 text-center"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Entrar em contato</span>
              </a>

              <a
                href="#cardapio"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-sm font-medium text-main hover:text-secondary-gold border border-white/10 hover:border-gold rounded-lg transition-all duration-300 text-center bg-surface/40 backdrop-blur-sm"
              >
                <UtensilsCrossed className="w-4 h-4 text-secondary-gold" />
                <span>Ver cardápio</span>
              </a>
            </div>

            {/* Clean trust metadata (unboxed, no pills) */}
            <div className="mt-12 flex items-center gap-4 text-xs text-muted/80">
              <span>Forno a 450°C</span>
              <span aria-hidden="true" className="text-secondary-gold/40">·</span>
              <span>São José dos Pinhais</span>
              <span aria-hidden="true" className="text-secondary-gold/40">·</span>
              <span>Entrega e Salão</span>
            </div>
          </motion.div>

          {/* Right Column: Heroic, Stunning Imagery */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 relative"
          >
            <div className="relative mx-auto max-w-xl lg:max-w-none group">
              {/* Subtle glowing frame border */}
              <div className="absolute -inset-1.5 rounded-2xl bg-gradient-to-tr from-[#E31837]/30 via-transparent to-[#D4AF37]/30 blur-lg opacity-70 group-hover:opacity-100 transition-opacity duration-700" />
              
              <div className="relative aspect-[16/10] sm:aspect-[16/11] rounded-xl overflow-hidden border border-subtle bg-surface shadow-2xl">
                <img
                  src="/src/assets/images/hero_artisan_pizza_1792118356987.jpg"
                  alt="Pizza artesanal napolitana assada no forno a lenha na Dina Pizza"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  loading="eager"
                />
                {/* Measured vignette scrim */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0908]/70 via-transparent to-transparent pointer-events-none" />
                
                {/* Minimalist photograph caption tag */}
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-white/90">
                  <span className="font-display italic text-secondary-light">Massa napolitana artesanal</span>
                  <span className="tabular-nums font-mono text-[11px] text-white/60">48h levain</span>
                </div>
              </div>
            </div>
          </motion.div>

        </div>
      </div>

      {/* Invite to scroll */}
      <div className="max-w-7xl mx-auto px-6 sm:px-8 w-full pt-8 flex items-center justify-between border-t border-white/5 text-xs text-muted/60">
        <span>Role para descobrir o cardápio</span>
        <a
          href="#cardapio"
          aria-label="Ir para o cardápio"
          className="p-2 text-muted hover:text-secondary-gold transition-colors animate-bounce"
        >
          <ArrowDown className="w-4 h-4" />
        </a>
      </div>
    </section>
  );
};
