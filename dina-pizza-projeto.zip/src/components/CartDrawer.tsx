import React from 'react';
import { X, Trash2, ArrowRight, MessageCircle } from 'lucide-react';
import { PizzaItem, RESTAURANT_INFO } from '../data/menu';

export interface CartItem {
  item: PizzaItem;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemove: (id: string) => void;
  onClear: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemove,
}) => {
  if (!isOpen) return null;

  const total = cart.reduce((acc, current) => acc + current.item.price * current.quantity, 0);

  const handleCheckoutWhatsApp = () => {
    let message = `Olá, Dina Pizza! Gostaria de fazer o seguinte pedido:\n\n`;
    cart.forEach((c) => {
      message += `• ${c.quantity}x *${c.item.name}* — R$ ${c.item.price * c.quantity}\n`;
    });
    message += `\n*Total:* R$ ${total}\n\nComo procedo com o pagamento e entrega?`;

    const url = `https://wa.me/${RESTAURANT_INFO.phoneSanitized}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <aside className="w-screen max-w-md bg-[#0E0B0A] border-l border-subtle shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 border-b border-subtle flex items-center justify-between">
            <div>
              <h2 className="font-display text-xl font-bold text-main">
                Seu Pedido
              </h2>
              <p className="text-xs text-muted">Cardápio Digital Dina Pizza</p>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Fechar carrinho"
              className="p-2 text-muted hover:text-white transition-colors rounded-lg hover:bg-white/5"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Items list */}
          <div className="p-6 overflow-y-auto flex-1 flex flex-col gap-4">
            {cart.length === 0 ? (
              <div className="my-auto text-center py-12">
                <p className="text-muted text-sm font-light mb-4">
                  Seu pedido ainda está vazio.
                </p>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-secondary-gold border border-gold/40 rounded-lg hover:bg-secondary-gold/10 transition-colors"
                >
                  Explorar Pizzas
                </button>
              </div>
            ) : (
              cart.map(({ item, quantity }) => (
                <div
                  key={item.id}
                  className="flex items-center gap-4 p-4 rounded-xl bg-surface border border-subtle"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-16 rounded-lg object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-display font-bold text-sm text-main truncate">
                      {item.name}
                    </h4>
                    <p className="text-xs text-secondary-gold tabular-nums mt-0.5">
                      R$ {item.price * quantity}
                    </p>
                    <div className="flex items-center gap-3 mt-2">
                      <div className="flex items-center border border-white/10 rounded-md overflow-hidden bg-[#0B0908]">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.id, -1)}
                          className="px-2 py-0.5 text-xs text-muted hover:text-main"
                        >
                          -
                        </button>
                        <span className="px-2 text-xs text-main font-mono tabular-nums">
                          {quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.id, 1)}
                          className="px-2 py-0.5 text-xs text-muted hover:text-main"
                        >
                          +
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRemove(item.id)}
                        className="text-muted/60 hover:text-primary-pepperoni transition-colors p-1"
                        aria-label="Remover pizza"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer checkout */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-subtle bg-surface/50 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted">Subtotal</span>
                <span className="font-display text-2xl font-bold text-secondary-gold tabular-nums">
                  R$ {total}
                </span>
              </div>

              <button
                type="button"
                onClick={handleCheckoutWhatsApp}
                className="w-full py-4 px-6 text-xs font-semibold uppercase tracking-wider text-white bg-primary-pepperoni hover:bg-primary-hover rounded-lg transition-all duration-300 flex items-center justify-center gap-2 shadow-xl shadow-[#E31837]/25"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Finalizar Pedido no WhatsApp</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

        </aside>
      </div>
    </div>
  );
};
